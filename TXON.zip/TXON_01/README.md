# pepsi-landing-page-responsive
Diseño web Responsive esta diseñada en HTML, CSS, JS.

![pepsi-laptop](https://user-images.githubusercontent.com/53599271/92312592-80186e00-efc2-11ea-881c-1ce2850b565f.png)

![pepsi-red](https://user-images.githubusercontent.com/53599271/92312661-18165780-efc3-11ea-9710-3cc2b25c0c09.png)

![pepsi-black](https://user-images.githubusercontent.com/53599271/92312662-1c427500-efc3-11ea-9385-ebbd969e3679.png)

![pepsi-tablet](https://user-images.githubusercontent.com/53599271/92312596-8ad30300-efc2-11ea-8ff6-e7430a4c11ae.png)

![pepsi-movil](https://user-images.githubusercontent.com/53599271/92312598-8dcdf380-efc2-11ea-8399-6c7fb6f2f2f5.png)
